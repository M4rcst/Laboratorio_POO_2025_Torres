
package com.example.demo.controller;

import java.util.Map;
import org.springframework.web.bind.annotation.*;
import com.example.demo.service.WeatherService;
import org.json.JSONObject;

@RestController
public class WeatherController {

    private final WeatherService weatherService;

    public WeatherController(WeatherService weatherService) {
        this.weatherService = weatherService;
    }

    @GetMapping("/weather")
    public Map<String, Object> getWeather(@RequestParam String city) {

        JSONObject weather = weatherService.fetchWeather(city);

        if (weather == null) {
            return Map.of("error", "Unable to fetch weather information");
        }

        double temperature = weather.getDouble("temperature");
        String status = weatherService.getTemperatureStatus(temperature);

        return Map.of(
            "city", city,
            "temperature", temperature,
            "status", status
        );
    }
}

