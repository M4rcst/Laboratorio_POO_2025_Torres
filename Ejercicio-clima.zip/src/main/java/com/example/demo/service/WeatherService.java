
package com.example.demo.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.json.JSONObject;

@Service
public class WeatherService {

    private final RestTemplate restTemplate;

    public WeatherService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public JSONObject fetchWeather(String city) {
        try {
            String geocodingUrl = "https://geocoding-api.open-meteo.com/v1/search?name=" + city;
            String geocodingResponse = restTemplate.getForObject(geocodingUrl, String.class);
            JSONObject geocodingJson = new JSONObject(geocodingResponse);

            if (!geocodingJson.has("results")) {
                return null;
            }

            JSONObject cityData = geocodingJson.getJSONArray("results").getJSONObject(0);

            double latitude = cityData.getDouble("latitude");
            double longitude = cityData.getDouble("longitude");

            String weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=" + latitude +
                                "&longitude=" + longitude +
                                "&current_weather=true";

            String weatherResponse = restTemplate.getForObject(weatherUrl, String.class);
            JSONObject weatherJson = new JSONObject(weatherResponse);

            return weatherJson.getJSONObject("current_weather");

        } catch (Exception e) {
            return null;
        }
    }

    public String getTemperatureStatus(double temperature) {
        if (temperature < 15) return "cold";
        if (temperature <= 30) return "mild";
        return "hot";
    }
}

