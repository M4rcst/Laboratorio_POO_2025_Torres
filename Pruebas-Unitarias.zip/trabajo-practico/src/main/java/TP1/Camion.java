package TP1;

public class Camion extends Vehiculo {
    private String carga_maxima;

    public String getCarga_maxima() { return carga_maxima; }
    public void setCarga_maxima(String carga_maxima) { this.carga_maxima = carga_maxima; }
    
    @Override
    public void mover() { }
}