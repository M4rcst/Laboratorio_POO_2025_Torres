package TP1;

public class Auto extends Vehiculo {
    private String tipo_combustible;

    public String getTipo_combustible() { return tipo_combustible; }
    public void setTipo_combustible(String tipo_combustible) { this.tipo_combustible = tipo_combustible; }
    
    @Override
    public void mover() { }
}