package TP1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class VehiculoTest {
    @Test
    public void testAuto() {
        Auto a = new Auto();
        a.setPlaca("AAA111");
        a.setTipo_combustible("Diesel");
        assertEquals("AAA111", a.getPlaca());
        assertEquals("Diesel", a.getTipo_combustible());
    }

    @Test
    public void testMoto() {
        Moto m = new Moto();
        m.setCilindrada("250cc");
        assertEquals("250cc", m.getCilindrada());
    }

    @Test
    public void testCamion() {
        Camion c = new Camion();
        c.setCapacidad(5);
        c.setCarga_maxima("10ton");
        assertEquals(5, c.getCapacidad());
        assertEquals("10ton", c.getCarga_maxima());
    }
}