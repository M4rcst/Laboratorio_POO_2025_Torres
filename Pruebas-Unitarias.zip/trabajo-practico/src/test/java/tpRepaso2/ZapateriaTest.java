package tpRepaso2;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class ZapateriaTest {
    private sucursal s1;
    private empresa emp;

    @BeforeEach
    public void setUp() {
        emp = new empresa();
        s1 = new sucursal("Centro", 10000); // Alquiler 10000
    }

    @Test
    public void testPreciosVenta() {
        sandalia san = new sandalia(1, 35, 1000);
        assertEquals(1000, san.getPrecioVenta());

        borcego bor = new borcego(2, 40, 1000);
        assertEquals(1200, bor.getPrecioVenta()); // 1000 * 1.2

        taco tac = new taco(3, 37, 1000);
        assertEquals(1300, tac.getPrecioVenta()); // 1000 * 1.3
        
        tacoLuisXV luisNac = new tacoLuisXV(4, 38, 1000, false);
        assertEquals(1300, luisNac.getPrecioVenta()); // Igual a taco

        tacoLuisXV luisImp = new tacoLuisXV(5, 38, 1000, true);
        assertEquals(1950, luisImp.getPrecioVenta()); // (1000 * 1.3) * 1.5
    }

    @Test
    public void testCapitalSucursal() {
        // Sandalia (1000) + Borcego (1200) = 2200 ventas.
        // Alquiler 10000. Capital = 2200 - 10000 = -7800
        s1.agregarCalzado(new sandalia(1, 35, 1000));
        s1.agregarCalzado(new borcego(2, 40, 1000));
        assertEquals(-7800, s1.calcularCapital());
    }

    @Test
    public void testRefinada() {
        s1.agregarCalzado(new sandalia(1, 35, 20000)); // > 15000
        assertTrue(s1.esRefinada());

        s1.agregarCalzado(new sandalia(2, 35, 10000)); // < 15000
        assertFalse(s1.esRefinada());
    }

    @Test
    public void testLiquidacion() {
        // Entra: precio < 15000
        s1.agregarCalzado(new sandalia(1, 35, 10000)); 
        // Entra: borcego y talle >= 40
        s1.agregarCalzado(new borcego(2, 41, 20000)); 
        // No entra: borcego talle chico y caro
        s1.agregarCalzado(new borcego(3, 38, 20000)); 

        emp.agregarSucursal(s1);
        assertEquals(2, emp.calzadosEnLiquidacion().size());
    }
}