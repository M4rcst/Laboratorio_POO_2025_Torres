package com.example.demo.model;

public class PokemonResult {
    private String name;
    private String url;

    public PokemonResult() {}

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
}
