package com.example.demo.model;

import java.util.List;

public class PokemonRespuesta {
    private List<PokemonResult> results;

    public PokemonRespuesta() {}

    public List<PokemonResult> getResults() { return results; }
    public void setResults(List<PokemonResult> results) { this.results = results; }
}
