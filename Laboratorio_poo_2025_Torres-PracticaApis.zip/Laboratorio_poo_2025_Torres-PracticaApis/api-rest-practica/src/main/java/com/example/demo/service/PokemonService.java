package com.example.demo.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.PokemonRespuesta;

@Service
public class PokemonService {

    private final RestTemplate restTemplate;

    public PokemonService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // Devuelve la respuesta mapeada con Jackson
    public PokemonRespuesta traerPokemones() {
        String url = "https://pokeapi.co/api/v2/pokemon?limit=5";
        return restTemplate.getForObject(url, PokemonRespuesta.class);
    }

    // Imprime algunos campos en consola (punto 3)
    public void mostrarPokemonesEnConsola() {
        PokemonRespuesta respuesta = traerPokemones();
        if (respuesta != null && respuesta.getResults() != null) {
            respuesta.getResults().forEach(p -> {
                System.out.println("Nombre: " + p.getName());
                System.out.println("URL: " + p.getUrl());
                System.out.println();
            });
        } else {
            System.out.println("No se obtuvieron pokemones.");
        }
    }
}
